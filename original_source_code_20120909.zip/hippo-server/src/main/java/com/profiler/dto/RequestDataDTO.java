package com.profiler.dto;

public class RequestDataDTO {
	private long timestamp;
	private int dataType;
	private int dataHashCode;
	
}
