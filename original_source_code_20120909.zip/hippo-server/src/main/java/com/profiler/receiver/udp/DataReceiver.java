package com.profiler.receiver.udp;

public interface DataReceiver {
    void start();
    void shutdown();
}
