package com.profiler;

import org.junit.Test;

public class TomcatProfileDataReceiverTest {

    public static void main(String[] args) {
        TomcatProfileDataReceiver.main(args);
    }
}
