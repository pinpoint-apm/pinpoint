java -Xms1g -Xmx1g -classpath `find . -name '*.jar' | tr "\n" :` com.profiler.TomcatProfileDataReceiver
